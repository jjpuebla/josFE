import frappe
from frappe.model.document import Document

class UIRule(Document):
    pass
