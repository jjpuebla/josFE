# # Force override of core contact details logic
# from frappe.contacts import utils as contact_utils
# from josfe.api import contact_details_override

# contact_utils.get_contact_details = contact_details_override.get_contact_details
