# Copyright (c) 2025, JP and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestNotaCreditoFE(FrappeTestCase):
	pass
