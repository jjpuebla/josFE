import frappe

def send_invoice_email(queue_doc, pdf_file):
    """
    Send AUTORIZADO XML + generated PDF to customer's main contact email.
    """
    invoice_name = queue_doc.reference_name
    invoice = frappe.get_doc("Sales Invoice", invoice_name)

    # 1. Get customer main email
    contact = frappe.db.sql("""
        SELECT email_id
        FROM `tabContact`
        WHERE name = (
            SELECT parent FROM `tabDynamic Link`
            WHERE link_doctype = 'Customer'
              AND link_name = %s
            LIMIT 1
        )
        LIMIT 1
    """, invoice.customer, as_dict=True)

    recipient = contact[0].email_id if contact else invoice.contact_email

    if not recipient:
        frappe.throw(f"No email found for customer {invoice.customer}")

    # 2. Fetch XML file (already stored in AUTORIZADOS folder)
    xml_file = frappe.get_doc({
        "doctype": "File",
        "file_name": queue_doc.xml_filename,
        "attached_to_doctype": "Sales Invoice",
        "attached_to_name": invoice.name,
        "is_private": 1,
        "file_url": f"SRI/AUTORIZADOS/{queue_doc.xml_filename}"
    })

    # 3. Prepare attachments
    attachments = [pdf_file.file_url, xml_file.file_url]

    # 4. Send email
    frappe.sendmail(
        recipients=[recipient],
        subject=f"Factura Electrónica {invoice.name}",
        message=f"Adjunto encontrará su factura electrónica {invoice.name}.",
        attachments=attachments,
        queue=True
    )
