import frappe
from frappe.model.document import Document

class NotaCreditoFreeItem(Document):
    pass
