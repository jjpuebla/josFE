async function getSelectedWH() {
  const bootVal = (frappe.boot.jos_selected_establishment || "").trim();
  console.log("[josfe:getSelectedWH] bootVal =", bootVal);

  // Always fetch latest from server for debugging
  try {
    const r = await frappe.call("josfe.user_location.session.get_establishment_options");
    const srvVal = (r.message?.selected || "").trim();
    console.log("[josfe:getSelectedWH] serverVal =", srvVal);
    return srvVal || bootVal;
  } catch (e) {
    console.error("[josfe:getSelectedWH] server call failed", e);
    return bootVal;
  }
}

frappe.ui.form.on("Sales Invoice", {
  async onload_post_render(frm) {
    const wh = await getSelectedWH();
    enforceWarehouseLock(frm, wh);
  },
  async refresh(frm) {
    const wh = await getSelectedWH();
    enforceWarehouseLock(frm, wh);
  }
});

frappe.ui.form.on("Delivery Note", {
  async onload_post_render(frm) {
    const wh = await getSelectedWH();
    enforceWarehouseLock(frm, wh);
  },
  async refresh(frm) {
    const wh = await getSelectedWH();
    enforceWarehouseLock(frm, wh);
  }
});

function enforceWarehouseLock(frm, wh) {
  console.log("[josfe:enforceWarehouseLock] applying WH =", wh, "on doctype =", frm.doctype);

  if (!wh) {
    frappe.show_alert({ message: "Debes seleccionar un Establecimiento", indicator: "red" });
    frappe.set_route("location-picker");
    return;
  }

  if (frm.doc.custom_jos_level3_warehouse !== wh) {
    console.log("[josfe:enforceWarehouseLock] setting header field to", wh);
    frm.set_value("custom_jos_level3_warehouse", wh);
  }

  const fld = frm.fields_dict?.set_warehouse;
  if (fld && fld.df) {
    console.log("[josfe:enforceWarehouseLock] setting set_warehouse default =", wh);
    fld.df.default = wh;
    try { frm.refresh_field("set_warehouse"); } catch (e) {}
  }

  if (frm.fields_dict.items) {
    const grid = frm.fields_dict.items.grid;
    const whField = grid.get_field("warehouse");
    if (whField) {
      console.log("[josfe:enforceWarehouseLock] locking item warehouses to", wh);
      whField.get_query = () => ({ filters: { name: wh } });
    }
  }
}
