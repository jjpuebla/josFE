# -*- coding: utf-8 -*-
import frappe
from pymysql.err import OperationalError
from frappe.utils import now_datetime, has_common
from frappe.exceptions import DuplicateEntryError

# ---- Constants ----
FIELD_BY_TYPE = {
    "Factura": "seq_factura",
    "Nota de Crédito": "seq_nc",
    "Nota de Débito": "seq_nd",
    "Comprobante Retención": "seq_ret",
    "Liquidación Compra": "seq_liq",
    "Guía de Remisión": "seq_gr",
}

PRIV_ROLES = {"System Manager", "Accounts Manager"}  # adjust if needed
CHILD_DOCTYPE = "SRI Puntos Emision"
CHILD_TABLE = f"`tab{CHILD_DOCTYPE}`"

# Possible child table fieldnames on Warehouse (first match wins)
WAREHOUSE_CHILD_FIELDS = (
    "custom_jos_SRI_puntos_emision",
    "custom_jos_Sri_puntos_emision",
    "custom_sri_puntos_emision",
)

# ---- Helpers ----
def _require_privileged():
    roles = set(frappe.get_roles(frappe.session.user))
    if not has_common(list(PRIV_ROLES), list(roles)):
        frappe.throw("You do not have permission to adjust sequentials. Contact a System Manager.")

def _choose_parentfield_for_wh() -> str:
    meta = frappe.get_meta("Warehouse")
    for f in WAREHOUSE_CHILD_FIELDS:
        df = meta.get_field(f)
        if df and df.fieldtype == "Table" and (df.options or "").strip() == CHILD_DOCTYPE:
            return f
    return WAREHOUSE_CHILD_FIELDS[0]

def _active_estado_value() -> str:
    """Return the correct 'active' option exactly as defined in the child DocType."""
    try:
        meta = frappe.get_meta(CHILD_DOCTYPE)
        fld = meta.get_field("estado")
        opts_raw = (fld.options or "").splitlines()
        opts = [o.strip() for o in opts_raw if o and o.strip()]
        if opts:
            for cand in opts:
                if cand.lower() in ("activo", "activa", "active"):
                    return cand
            return opts[0]
    except Exception:
        pass
    return "Activo"

def _zpad3(s: str) -> str:
    return str(s or "").strip().zfill(3)

def _get_establishment_code(warehouse_name: str) -> str:
    est = (frappe.db.get_value("Warehouse", warehouse_name, "custom_establishment_code") or "").strip()
    if not est:
        frappe.throw(f"Warehouse '{warehouse_name}' has no establishment code (custom_establishment_code).")
    return _zpad3(est)

def _row_by_name_locked(row_name: str):
    if not row_name:
        return None
    rows = frappe.db.sql(
        f"""
        SELECT name, parent, emission_point_code, estado,
               seq_factura, seq_nc, seq_nd, seq_ret, seq_liq, seq_gr, initiated
        FROM {CHILD_TABLE}
        WHERE name=%s
        FOR UPDATE
        """,
        (row_name,),
        as_dict=True,
    )
    return rows[0] if rows else None

def _find_row_in_same_warehouse_locked(warehouse_name: str, emission_point_code: str):
    target = _zpad3(emission_point_code)
    rows = frappe.db.sql(
        f"""
        SELECT name, parent, emission_point_code, estado,
               seq_factura, seq_nc, seq_nd, seq_ret, seq_liq, seq_gr, initiated
        FROM {CHILD_TABLE}
        WHERE parent=%s
          AND parenttype='Warehouse'
          AND (parentfield=%s OR parentfield=%s OR parentfield=%s)
          AND LPAD(TRIM(emission_point_code), 3, '0')=%s
        FOR UPDATE
        """,
        (warehouse_name, WAREHOUSE_CHILD_FIELDS[0], WAREHOUSE_CHILD_FIELDS[1], WAREHOUSE_CHILD_FIELDS[2], target),
        as_dict=True,
    )
    return rows[0] if rows else None

def _intended_child_name(warehouse_name: str, emission_point_code: str) -> str:
    """Name strategy = <EST>-<EP>. This prevents global collisions while keeping names human-friendly."""
    est = _get_establishment_code(warehouse_name)
    ep = _zpad3(emission_point_code)
    return f"{est}-{ep}"

def _insert_child_row(warehouse_name: str, emission_point_code: str):
    """
    Insert a child row for THIS Warehouse with name = "<EST>-<EP>".
    If there's a global name collision (old/orphan row), reuse if it already belongs here,
    else append a short hash suffix.
    """
    pf = _choose_parentfield_for_wh()
    target = _zpad3(emission_point_code)
    intended_name = _intended_child_name(warehouse_name, target)

    # Build doc
    child = frappe.get_doc({
        "doctype": CHILD_DOCTYPE,
        "name": intended_name,                # <-- explicit name
        "parent": warehouse_name,
        "parenttype": "Warehouse",
        "parentfield": pf,
        "emission_point_code": target,
        "estado": _active_estado_value(),
        "seq_factura": 0, "seq_nc": 0, "seq_nd": 0, "seq_ret": 0, "seq_liq": 0, "seq_gr": 0,
        "initiated": 0,
    })
    child.flags.name_set = True  # keep our custom name even if autoname is configured

    try:
        child.insert(ignore_permissions=True)
        return _row_by_name_locked(child.name)

    except DuplicateEntryError:
        # Name already exists globally. Check who owns it.
        existing = _row_by_name_locked(intended_name)
        if existing and existing.get("parent") == warehouse_name:
            return existing  # already ours

        # Someone else has the same name (shouldn't happen if EST is truly global-unique,
        # but handle gracefully: suffix a short hash)
        suffix = frappe.generate_hash(length=8)
        child.name = f"{intended_name}-{suffix}"
        child.flags.name_set = True
        child.insert(ignore_permissions=True)
        return _row_by_name_locked(child.name)

def _get_or_create_row_by_parent_code_locked(warehouse_name: str, emission_point_code: str):
    """
    Find child row by (warehouse, EP). If missing, create it for *this* Warehouse.
    EP can repeat across Warehouses. Establishment code is globally unique at Warehouse level.
    """
    existing = _find_row_in_same_warehouse_locked(warehouse_name, emission_point_code)
    if existing:
        return existing
    return _insert_child_row(warehouse_name, emission_point_code)

def _get_active_row_by_parent_code_locked(warehouse_name: str, emission_point_code: str):
    """Find an ACTIVO emission point row for this Warehouse and lock it. Do NOT auto-create for issuing."""
    target = _zpad3(emission_point_code)
    rows = frappe.db.sql(
        f"""
        SELECT name, parent, emission_point_code, estado,
               seq_factura, seq_nc, seq_nd, seq_ret, seq_liq, seq_gr, initiated
        FROM {CHILD_TABLE}
        WHERE parent=%s
          AND parenttype='Warehouse'
          AND (parentfield=%s OR parentfield=%s OR parentfield=%s)
          AND LPAD(TRIM(emission_point_code), 3, '0')=%s
          AND UPPER(TRIM(estado))='ACTIVO'
        FOR UPDATE
        """,
        (warehouse_name, WAREHOUSE_CHILD_FIELDS[0], WAREHOUSE_CHILD_FIELDS[1], WAREHOUSE_CHILD_FIELDS[2], target),
        as_dict=True,
    )
    if not rows:
        frappe.throw(f"No active emission point {_zpad3(emission_point_code)} in Warehouse {warehouse_name}.")
    return rows[0]

def _log(warehouse, emission_point_code, doc_type, action, old_val, new_val, note=""):
    frappe.get_doc({
        "doctype": "SRI Secuencial Log",
        "warehouse": warehouse,
        "emission_point_code": emission_point_code,
        "doc_type": doc_type,           # Factura, Retención, etc.
        "action": action,               # INIT / EDIT / AUTO
        "old_value": int(old_val),
        "new_value": int(new_val),
        "note": note,
        "by_user": frappe.session.user,
        "when": now_datetime(),
    }).insert(ignore_permissions=True)

def _with_retry(fn, *args, **kwargs):
    """Retry on deadlock/lock-wait."""
    for attempt in range(3):
        try:
            return fn(*args, **kwargs)
        except OperationalError as e:
            code = e.args[0] if e.args else None
            if code in (1205, 1213) and attempt < 2:
                frappe.db.rollback()
                continue
            raise

def _has_field(doctype: str, fieldname: str) -> bool:
    try:
        return bool(frappe.get_meta(doctype).get_field(fieldname))
    except Exception:
        return False

# ---- Public APIs ----
@frappe.whitelist()
def initiate_or_edit(
    warehouse_name: str,
    row_name: str | None = None,
    updates_dict=None,
    note: str = "",
    emission_point_code: str | None = None,
):
    """
    INIT: when initiated=0, set provided seq_* and mark initiated=1. (UI enforces all six ≥ 1.)
    EDIT: when initiated=1, allow equal (no-op), error only if LOWER.

    If row_name is not resolvable (brand-new UI row), resolve or create by (warehouse, emission_point_code).
    """
    _require_privileged()

    if isinstance(updates_dict, str):
        import json
        updates_dict = json.loads(updates_dict or "{}")
    updates_dict = updates_dict or {}

    def inner():
        row = _row_by_name_locked(row_name) if row_name else None
        if not row:
            if not emission_point_code:
                frappe.throw("Emission point row not found (missing emission_point_code).")
            row = _get_or_create_row_by_parent_code_locked(warehouse_name, emission_point_code)

        if row["parent"] != warehouse_name:
            frappe.throw("The selected row does not belong to this Warehouse.")

        action = "EDIT" if int(row.get("initiated") or 0) else "INIT"
        updates = {}

        for doc_type, new_val in updates_dict.items():
            field = FIELD_BY_TYPE.get(doc_type)
            if not field:
                frappe.throw(f"Unsupported doc_type: {doc_type}")

            try:
                new_val = int(new_val)
            except Exception:
                frappe.throw(f"{doc_type}: value must be an integer.")

            old_val = int(row.get(field) or 0)

            if action == "EDIT":
                if new_val < old_val:
                    frappe.throw(f"{doc_type}: new value {new_val} must not be lower than current {old_val}.")
                if new_val == old_val:
                    continue  # equal → allowed, skip write/log

            updates[field] = new_val
            _log(warehouse_name, row.get("emission_point_code"), doc_type, action, old_val, new_val, note)

        if updates:
            to_write = dict(updates)
            if note and _has_field(CHILD_DOCTYPE, "last_adjust_note"):
                to_write["last_adjust_note"] = note
            frappe.db.set_value(CHILD_DOCTYPE, row["name"], to_write, update_modified=False)

        if action == "INIT" and not int(row.get("initiated") or 0):
            frappe.db.set_value(CHILD_DOCTYPE, row["name"], "initiated", 1, update_modified=False)

        return {"status": "ok", "action": action, "updated": updates}

    return _with_retry(inner)

@frappe.whitelist()
def next_sequential(warehouse_name: str, emission_point_code: str, doc_type: str) -> int:
    """
    Atomic increment used by issuing flows (before_submit). Returns the NEW value.
    Requires emission point ACTIVO.
    """
    field = FIELD_BY_TYPE.get(doc_type)
    if not field:
        frappe.throw(f"Unsupported doc_type: {doc_type}")

    def inner():
        row = _get_active_row_by_parent_code_locked(warehouse_name, emission_point_code)
        curr = int(row.get(field) or 0)
        newv = curr + 1
        frappe.db.set_value(CHILD_DOCTYPE, row["name"], field, newv, update_modified=False)
        _log(warehouse_name, row.get("emission_point_code"), doc_type, "AUTO", curr, newv, "auto-increment on issuance")
        return newv

    return _with_retry(inner)

@frappe.whitelist()
def peek_next(warehouse_name: str, emission_point_code: str, doc_type: str) -> int:
    """
    Read-only preview: returns current+1 without writing.
    Requires emission point ACTIVO.
    """
    field = FIELD_BY_TYPE.get(doc_type)
    if not field:
        frappe.throw(f"Unsupported doc_type: {doc_type}")

    row = _get_active_row_by_parent_code_locked(warehouse_name, emission_point_code)
    curr = int(row.get(field) or 0)
    return curr + 1
