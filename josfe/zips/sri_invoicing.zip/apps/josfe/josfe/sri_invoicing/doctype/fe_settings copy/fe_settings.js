// Copyright (c) 2025, JP and contributors
// For license information, please see license.txt

// frappe.ui.form.on("FE Settings", {
// 	refresh(frm) {

// 	},
// });
