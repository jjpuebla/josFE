# -*- coding: utf-8 -*-
from __future__ import annotations
from xml.etree import ElementTree as ET
import datetime, base64, random

from cryptography import x509
from cryptography.hazmat.backends import default_backend

ET.register_namespace("ds", "http://www.w3.org/2000/09/xmldsig#")
ET.register_namespace("etsi", "http://uri.etsi.org/01903/v1.3.2#")

DS = "http://www.w3.org/2000/09/xmldsig#"
ETSI = "http://uri.etsi.org/01903/v1.3.2#"
NS = {"ds": DS, "etsi": ETSI}


def _int_to_b64(n: int) -> str:
    if n == 0:
        return base64.b64encode(b"\x00").decode("ascii")
    blen = (n.bit_length() + 7) // 8
    return base64.b64encode(n.to_bytes(blen, "big")).decode("ascii")


def _load_cert_bits(cert_pem_path: str):
    pem = open(cert_pem_path, "rb").read()
    cert = x509.load_pem_x509_certificate(pem, default_backend())
    der = cert.public_bytes(x509.Encoding.DER)
    cert_b64 = base64.b64encode(der).decode("ascii")
    # SHA1 digest of DER (for xades:CertDigest)
    from hashlib import sha1
    digest_b64 = base64.b64encode(sha1(der).digest()).decode("ascii")
    issuer = cert.issuer.rfc4514_string()
    serial = cert.serial_number
    # RSA modulus / exponent from cert's public key
    pub = cert.public_key()
    try:
        nums = pub.public_numbers()
        modulus_b64 = _int_to_b64(nums.n)
        exponent_b64 = _int_to_b64(nums.e)
    except Exception:
        # Not RSA? (shouldn’t happen given your checks)
        modulus_b64 = exponent_b64 = ""
    return {
        "cert_b64": cert_b64,
        "digest_b64": digest_b64,
        "issuer": issuer,
        "serial": serial,
        "modulus_b64": modulus_b64,
        "exponent_b64": exponent_b64,
    }


TEMPLATE = """<ds:Signature Id="Signature{sig_id}"
  xmlns:ds="http://www.w3.org/2000/09/xmldsig#"
  xmlns:etsi="http://uri.etsi.org/01903/v1.3.2#">
  <ds:SignedInfo Id="Signature-SignedInfo{signedinfo_id}">
    <ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
    <ds:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
    <!-- Reference to SignedProperties -->
    <ds:Reference Id="SignedPropertiesID{props_id}" Type="http://uri.etsi.org/01903#SignedProperties"
                  URI="#Signature{sig_id}-SignedProperties{props_id}">
      <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
      <ds:DigestValue></ds:DigestValue>
    </ds:Reference>
    <!-- Reference to KeyInfo -->
    <ds:Reference URI="#Certificate{cert_id}">
      <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
      <ds:DigestValue></ds:DigestValue>
    </ds:Reference>
    <!-- Reference to comprobante -->
    <ds:Reference Id="Reference-ID-{comp_ref}" URI="#comprobante">
      <ds:Transforms>
        <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
        <ds:Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
      </ds:Transforms>
      <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
      <ds:DigestValue></ds:DigestValue>
    </ds:Reference>
  </ds:SignedInfo>

  <ds:SignatureValue></ds:SignatureValue>

  <ds:KeyInfo Id="Certificate{cert_id}">
    <ds:X509Data>
      <ds:X509Certificate></ds:X509Certificate>
    </ds:X509Data>
    <ds:KeyValue>
      <ds:RSAKeyValue>
        <ds:Modulus></ds:Modulus>
        <ds:Exponent></ds:Exponent>
      </ds:RSAKeyValue>
    </ds:KeyValue>
  </ds:KeyInfo>

  <ds:Object Id="Signature{sig_id}-Object{obj_id}">
    <etsi:QualifyingProperties Target="#Signature{sig_id}">
      <etsi:SignedProperties Id="Signature{sig_id}-SignedProperties{props_id}">
        <etsi:SignedSignatureProperties>
          <etsi:SigningTime></etsi:SigningTime>
          <etsi:SigningCertificate>
            <etsi:Cert>
              <etsi:CertDigest>
                <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
                <ds:DigestValue></ds:DigestValue>
              </etsi:CertDigest>
              <etsi:IssuerSerial>
                <ds:X509IssuerName></ds:X509IssuerName>
                <ds:X509SerialNumber></ds:X509SerialNumber>
              </etsi:IssuerSerial>
            </etsi:Cert>
          </etsi:SigningCertificate>
        </etsi:SignedSignatureProperties>
        <etsi:SignedDataObjectProperties>
          <etsi:DataObjectFormat ObjectReference="#Reference-ID-{comp_ref}">
            <etsi:Description>contenido comprobante</etsi:Description>
            <etsi:MimeType>text/xml</etsi:MimeType>
          </etsi:DataObjectFormat>
        </etsi:SignedDataObjectProperties>
      </etsi:SignedProperties>
    </etsi:QualifyingProperties>
  </ds:Object>
</ds:Signature>
""".strip()


def inject_signature_template(xml_text: str, cert_pem_path: str) -> str:
    """
    Inject the authorized-style XAdES signature template into the factura.
    """
    root = ET.fromstring(xml_text)
    if not root.tag.endswith("factura"):
        raise ValueError("Root XML is not <factura>.")

    # factura id="comprobante"
    if root.get("id") != "comprobante":
        root.attrib.pop("Id", None)
        root.set("id", "comprobante")

    # Randomized suffixes (mimic autorizado)
    sig_id = random.randint(100000, 999999)
    signedinfo_id = random.randint(100000, 999999)
    props_id = random.randint(100000, 999999)
    cert_id = random.randint(1000000, 9999999)
    comp_ref = random.randint(100000, 999999)
    obj_id = random.randint(10000, 99999)

    sig_xml = TEMPLATE.format(
        sig_id=sig_id,
        signedinfo_id=signedinfo_id,
        props_id=props_id,
        cert_id=cert_id,
        comp_ref=comp_ref,
        obj_id=obj_id,
    )
    sig_el = ET.fromstring(sig_xml)

    # Fill dynamic parts
    bits = _load_cert_bits(cert_pem_path)

    # SigningTime
    el = sig_el.find(".//etsi:SigningTime", NS)
    if el is not None:
        el.text = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    # KeyInfo/X509Data/Certificate
    el = sig_el.find(".//ds:KeyInfo/ds:X509Data/ds:X509Certificate", NS)
    if el is not None:
        el.text = bits["cert_b64"]

    # RSAKeyValue
    m = sig_el.find(".//ds:KeyValue/ds:RSAKeyValue/ds:Modulus", NS)
    if m is not None:
        m.text = bits["modulus_b64"]
    e = sig_el.find(".//ds:KeyValue/ds:RSAKeyValue/ds:Exponent", NS)
    if e is not None:
        e.text = bits["exponent_b64"]

    # xades SigningCertificate (digest + issuer + serial)
    d = sig_el.find(".//etsi:CertDigest/ds:DigestValue", NS)
    if d is not None:
        d.text = bits["digest_b64"]
    xname = sig_el.find(".//etsi:IssuerSerial/ds:X509IssuerName", NS)
    if xname is not None:
        xname.text = bits["issuer"]
    xsn = sig_el.find(".//etsi:IssuerSerial/ds:X509SerialNumber", NS)
    if xsn is not None:
        xsn.text = str(bits["serial"])

    # Append to document
    root.append(sig_el)
    return ET.tostring(root, encoding="utf-8").decode("utf-8")
import subprocess, tempfile, os

def sign_with_xmlsec(input_xml: bytes, key_pem_path: str, cert_pem_path: str) -> bytes:
    """
    Writes input_xml to a temp file, runs xmlsec1 with correct --id-attr flags,
    returns the signed XML bytes or raises RuntimeError with stderr.
    """
    with tempfile.TemporaryDirectory() as td:
        in_path = os.path.join(td, "in.xml")
        out_path = os.path.join(td, "out.xml")
        with open(in_path, "wb") as f:
            f.write(input_xml)

        cmd = [
            "xmlsec1", "--sign",
            "--privkey-pem", f"{key_pem_path},{cert_pem_path}",
            "--id-attr:id", "factura",
            "--id-attr:Id", "SignedProperties",
            "--id-attr:Id", "KeyInfo",
            "--output", out_path,
            in_path,
        ]
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if p.returncode != 0:
            raise RuntimeError(
                f"xmlsec1 failed:\n{p.stderr.decode('utf-8', 'ignore')}"
            )
        return open(out_path, "rb").read()
