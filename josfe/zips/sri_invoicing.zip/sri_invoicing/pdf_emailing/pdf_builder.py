# apps/josfe/josfe/sri_invoicing/pdf_emailing/pdf_builder.py
# -*- coding: utf-8 -*-

import os
import base64
import frappe
import xml.etree.ElementTree as ET
from io import BytesIO
from frappe.utils import getdate
from frappe.utils.pdf import get_pdf
from josfe.sri_invoicing.xml import paths as xml_paths

import qrcode
import barcode
import shutil, uuid
from barcode.writer import ImageWriter


# ---------------- QR + Barcode helpers ----------------

def _generate_qr_base64(clave_acceso: str) -> str:
    """Generate QR code for claveAcceso and return as base64 data URI."""
    if not clave_acceso:
        return ""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=4,
        border=2,
    )
    qr.add_data(clave_acceso)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"

def _file_to_base64(path: str) -> str:
    if not path or not os.path.exists(path):
        return ""
    with open(path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"

def _generate_barcode_base64(clave_acceso: str) -> str:
    """Generate Code128 barcode for claveAcceso as base64 data URI."""
    if not clave_acceso:
        return ""
    code128 = barcode.get("code128", clave_acceso, writer=ImageWriter())
    buffer = BytesIO()
    code128.write(buffer, options={"module_height": 8.0, "font_size": 5.5, "text_distance": 2.5 })
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


# ---------------- XML parser ----------------

def _parse_autorizado_xml(abs_xml_path: str) -> dict:
    """Parse AUTORIZADO XML and extract all relevant fields into a dict."""
    if not os.path.exists(abs_xml_path):
        return {}

    try:
        tree = ET.parse(abs_xml_path)
        root = tree.getroot()
    except Exception:
        frappe.log_error(frappe.get_traceback(), "Error parsing AUTORIZADO XML")
        return {}

    auth = {}

    # numeroAutorizacion + fechaAutorizacion come from wrapper
    for tag in ("numeroAutorizacion", "fechaAutorizacion", "ambiente", "tipoEmision"):
        el = root.find(f".//{tag}")
        if el is not None and el.text:
            auth[tag] = el.text.strip()

    # Parse <comprobante> inner XML (CDATA)
    comprobante_el = root.find(".//comprobante")
    if comprobante_el is not None and comprobante_el.text:
        try:
            inner_xml = comprobante_el.text.strip()
            inner_root = ET.fromstring(inner_xml)

            # Clave de Acceso (inside comprobante, not wrapper)
            el = inner_root.find(".//claveAcceso")
            if el is not None and el.text:
                auth["claveAcceso"] = el.text.strip()

            # Basic invoice fields
            for tag in (
                "razonSocialComprador",
                "identificacionComprador",
                "direccionComprador",
                "fechaEmision",
                "totalSinImpuestos",
                "totalDescuento",
                "importeTotal",
                "obligadoContabilidad",
                "ruc",
                "dirMatriz",
                "dirEstablecimiento",
                "estab",
                "ptoEmi",
                "secuencial",
            ):
                el = inner_root.find(f".//{tag}")
                if el is not None and el.text:
                    auth[tag] = el.text.strip()

            # Totals (list of impuestos)
            auth["totalConImpuestos"] = []
            for imp in inner_root.findall(".//totalImpuesto"):
                entry = {}
                for subtag in ("codigo", "codigoPorcentaje", "baseImponible", "valor"):
                    el = imp.find(subtag)
                    if el is not None and el.text:
                        entry[subtag] = el.text.strip()
                if entry:
                    auth["totalConImpuestos"].append(entry)

            # Pagos
            auth["pagos"] = []
            for pago in inner_root.findall(".//pago"):
                entry = {}
                for subtag in ("formaPago", "total"):
                    el = pago.find(subtag)
                    if el is not None and el.text:
                        entry[subtag] = el.text.strip()

                # add description mapping
                if "formaPago" in entry:
                    descriptions = {
                        "01": "SIN UTILIZACIÓN DEL SISTEMA FINANCIERO",
                        "15": "COMPENSACIÓN DE DEUDAS",
                        "16": "TARJETA DE DÉBITO",
                        "17": "DINERO ELECTRÓNICO",
                        "18": "TARJETA PREPAGO",
                        "19": "TARJETA DE CRÉDITO",
                        "20": "OTROS CON UTILIZACIÓN DEL SISTEMA FINANCIERO",
                        "21": "ENDOSO DE TÍTULOS",
                    }
                    entry["descripcion"] = descriptions.get(entry["formaPago"], entry["formaPago"])
                auth["pagos"].append(entry)
            # Información adicional
            auth["infoAdicional"] = []
            for campo in inner_root.findall(".//campoAdicional"):
                entry = {}
                if "nombre" in campo.attrib:
                    entry["nombre"] = campo.attrib["nombre"]
                entry["valor"] = campo.text.strip() if campo.text else ""
                if entry:
                    auth["infoAdicional"].append(entry)

            # ✅ INSERT HERE: Items (detalles)
            auth["items"] = []
            for det in inner_root.findall(".//detalle"):
                item = {}
                for tag in ("codigoPrincipal", "descripcion", "cantidad",
                            "precioUnitario", "descuento", "precioTotalSinImpuesto"):
                    el = det.find(tag)
                    if el is not None and el.text:
                        item[tag] = el.text.strip()

                # impuestos per item
                item["impuestos"] = []
                for imp in det.findall(".//impuesto"):
                    imp_entry = {}
                    for subtag in ("codigo", "codigoPorcentaje", "tarifa",
                                   "baseImponible", "valor"):
                        el = imp.find(subtag)
                        if el is not None and el.text:
                            imp_entry[subtag] = el.text.strip()
                    if imp_entry:
                        item["impuestos"].append(imp_entry)

                if item:
                    auth["items"].append(item)

        except Exception:
            frappe.log_error(frappe.get_traceback(), "Error parsing inner comprobante XML")

    # Add QR + barcode
    auth["qr"] = _generate_qr_base64(auth.get("claveAcceso"))
    auth["barcode"] = _generate_barcode_base64(auth.get("claveAcceso"))

    return auth


# ---------------- PDF builder ----------------

def build_invoice_pdf(qdoc) -> str:
    """
    Render Sales Invoice into PDF, enriched with values from AUTORIZADO XML.
    Saves under /private/files/SRI/RIDE/mm-YYYY/<QueueName>.pdf
    Returns the /private/files/... URL.
    """
    # Load linked Sales Invoice
    inv = None
    if qdoc.get("sales_invoice"):
        inv = frappe.get_doc("Sales Invoice", qdoc.sales_invoice)
    elif qdoc.get("reference_doctype") == "Sales Invoice":
        inv = frappe.get_doc("Sales Invoice", qdoc.reference_name)
    else:
        frappe.throw("SRI XML Queue row missing Sales Invoice link.")

    # Locate AUTORIZADO XML
    xml_url = qdoc.get("xml_file")
    auth_fields = {}
    if xml_url:
        abs_xml_path = frappe.get_site_path("private", "files", xml_url.replace("/private/files/", ""))
        auth_fields = _parse_autorizado_xml(abs_xml_path)

    # --- Company Logo Handling ---
    logo_base64 = ""
    logo_url = frappe.db.get_value("Company", inv.company, "company_logo")

    if logo_url:
        try:
            # Turn File URL into absolute path
            if logo_url.startswith("/private/files/"):
                abs_path = frappe.get_site_path("private", "files", logo_url.replace("/private/files/", ""))
            elif logo_url.startswith("/files/"):
                abs_path = frappe.get_site_path("public", "files", logo_url.replace("/files/", ""))
            else:
                abs_path = ""

            # Embed as base64 if file exists
            if abs_path and os.path.exists(abs_path):
                with open(abs_path, "rb") as f:
                    encoded = base64.b64encode(f.read()).decode("utf-8")
                logo_base64 = f"data:image/png;base64,{encoded}"
            else:
                frappe.log_error(f"Logo not found at {abs_path}", "PDF Logo Missing")
        except Exception:
            frappe.log_error(frappe.get_traceback(), "Error embedding company logo")

    auth_fields["logo_base64"] = logo_base64


    # Render template
    html = frappe.render_template(
        "josfe/sri_invoicing/pdf_emailing/templates/factura.html",
        {"doc": inv, "queue": qdoc, "auth": auth_fields},
    )
    pdf_bytes = get_pdf(html)

    # Save PDF under RIDE/mm-YYYY
    d = getdate(inv.posting_date)
    rel_dir = f"RIDE/{d.month:02d}-{d.year}"
    fname = f"{inv.name}.pdf"
    abs_path = xml_paths.abs_path(rel_dir, fname)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)

    with open(abs_path, "wb") as f:
        f.write(pdf_bytes)

    return xml_paths.to_file_url(rel_dir, fname)
