import frappe, os
from frappe.utils import getdate, cstr
from frappe.utils.pdf import get_pdf

def build_invoice_pdf(queue_doc):
    """
    Build PDF from Sales Invoice linked to SRI XML Queue.
    """
    invoice_name = queue_doc.reference_name
    invoice = frappe.get_doc("Sales Invoice", invoice_name)

    # Render Jinja2 template
    html = frappe.render_template(
        "josfe/sri_invoicing/pdf_emailing/templates/factura.html",
        {"doc": invoice, "queue": queue_doc}
    )
    pdf_content = get_pdf(html)

    # Folder = mm-yyyy from invoice.posting_date
    posting_date = getdate(invoice.posting_date)
    mm = cstr(posting_date.month).zfill(2)
    yyyy = posting_date.year
    month_year = f"{mm}-{yyyy}"

    # Absolute folder path
    site_path = frappe.get_site_path("private", "files", "SRI", "RIDE", month_year)
    os.makedirs(site_path, exist_ok=True)

    # File name = Queue Doc name.pdf
    file_name = f"{queue_doc.name}.pdf"
    file_path = os.path.join(site_path, file_name)

    # Write PDF to filesystem
    with open(file_path, "wb") as f:
        f.write(pdf_content)

    # Return relative path for browser
    return f"/private/files/SRI/RIDE/{month_year}/{file_name}"
