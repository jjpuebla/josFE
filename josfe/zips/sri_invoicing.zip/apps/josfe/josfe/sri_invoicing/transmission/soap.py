# -*- coding: utf-8 -*-
# apps/josfe/josfe/sri_invoicing/transmission/soap.py

from __future__ import annotations
import base64
from typing import Dict, Any, Optional, Tuple, List
import requests
from zeep import Client, Settings, helpers
from zeep.plugins import HistoryPlugin
from zeep.transports import Transport
from lxml import etree
import frappe

from .endpoints import resolve_wsdl, get_endpoint_flags

# apps/josfe/josfe/sri_invoicing/transmission/soap.py

AUTORIZACION_URLS = {
    "PRUEBAS": "https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl",
    "PRODUCCION": "https://cel.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl",
}

# --- DEBUG helper (place near the top of the file) ---
def _emit_debug(title: str, xml_text: str):
    try:
        # Lightweight: log up to ~80k chars so we don't blow logs
        snippet = (xml_text or "")[:80000]
        frappe.logger("sri").info({"title": title, "xml": snippet})
    except Exception:
        pass

def _get_autorizacion_url(ambiente: str) -> str:
    """
    Resolve SRI Autorización endpoint based on ambiente.
    ambiente can be "1"/"PRUEBAS" or "2"/"PRODUCCION".
    """
    key = (ambiente or "").strip().upper()
    if key in ("1", "PRUEBAS", "TEST"):
        return AUTORIZACION_URLS["PRUEBAS"]
    if key in ("2", "PRODUCCION", "PROD"):
        return AUTORIZACION_URLS["PRODUCCION"]
    # fallback
    return AUTORIZACION_URLS["PRUEBAS"]

def _ambiente_from_xml(xml_bytes: bytes) -> str:
    """
    Derive ambiente from the XML payload (infoTributaria/ambiente).
    SRI spec: 1=Pruebas, 2=Producción. Default to Pruebas.
    """
    try:
        root = etree.fromstring(xml_bytes)
        vals: List[str] = root.xpath('//*[local-name()="ambiente"]/text()')
        if vals:
            v = (vals[0] or "").strip()
            if v == "2" or v.lower().startswith("prod"):
                return "Producción"
            return "Pruebas"
    except Exception:
        pass
    # Fallback: naive scan
    try:
        text = xml_bytes.decode("utf-8", errors="ignore").lower()
        if ">2<" in text or "producción" in text or "produccion" in text:
            return "Producción"
    except Exception:
        pass
    return "Pruebas"

def _zeep_client(service: str, ambiente: str) -> Tuple[Client, HistoryPlugin]:
    wsdl = resolve_wsdl(service, ambiente)
    if not wsdl:
        raise RuntimeError(f"No WSDL configured for service={service}, ambiente={ambiente}")

    verify_ssl, timeout = get_endpoint_flags(service, ambiente)
    session = requests.Session()
    session.verify = verify_ssl
    transport = Transport(session=session, timeout=timeout)
    settings = Settings(strict=False, xml_huge_tree=True)

    history = HistoryPlugin()
    client = Client(wsdl=wsdl, transport=transport, settings=settings, plugins=[history])
    return client, history

def enviar_recepcion(xml_bytes: bytes, ambiente: Optional[str] = None, debug: bool = False) -> Dict[str, Any]:
    amb = ambiente or _ambiente_from_xml(xml_bytes)
    client, hist = _zeep_client("Recepción", amb)

    xml_b64 = base64.b64encode(xml_bytes).decode()
    try:
        res = client.service.validarComprobante(xml_b64)
        data = helpers.serialize_object(res) or {}
    except Exception as e:
        return {"estado": "ERROR", "mensajes": [f"Error de conexión/Zeep: {e!r}"], "raw_xml": "", "ambiente": amb}

    raw_soap_envelope = ""
    raw_respuesta = ""
    if hist.last_received and "envelope" in hist.last_received:
        raw_soap_envelope = etree.tostring(hist.last_received["envelope"], encoding="utf-8").decode("utf-8")
        try:
            root = etree.fromstring(raw_soap_envelope.encode("utf-8"))
            # extract <RespuestaRecepcionComprobante> only
            nodes = root.xpath('//*[local-name()="RespuestaRecepcionComprobante"]')
            if nodes:
                raw_respuesta = etree.tostring(nodes[0], encoding="utf-8").decode("utf-8")
        except Exception:
            pass

    estado = (data.get("estado") or "").upper()
    mensajes = []
    try:
        comps = (data.get("comprobantes") or {}).get("comprobante") or []
        if isinstance(comps, dict):
            comps = [comps]
        for c in comps:
            mm = (c.get("mensajes") or {}).get("mensaje") or []
            if isinstance(mm, dict):
                mm = [mm]
            for m in mm:
                mensajes.append({
                    "identificador": m.get("identificador"),
                    "mensaje": m.get("mensaje"),
                    "informacionAdicional": m.get("informacionAdicional"),
                    "tipo": m.get("tipo"),
                })
    except Exception:
        pass

    if debug:
        _emit_debug("SRI Recepción SOAP envelope", raw_soap_envelope)
        _emit_debug("SRI Recepción respuesta", raw_respuesta)

    # Keep legacy "raw_xml" for backward compatibility, and add richer fields
    return {
        "estado": estado,
        "mensajes": mensajes,
        "raw_xml": raw_soap_envelope,      # legacy key (SOAP)
        "raw_soap_envelope": raw_soap_envelope,
        "respuesta_xml": raw_respuesta,    # just the <RespuestaRecepcionComprobante> wrapper
        "ambiente": amb,
    }

# --- AUTORIZACIÓN: keep SOAP + <autorizacion> + inner comprobante ---
def consultar_autorizacion(clave_acceso: str, ambiente: str = "Pruebas", debug: bool = False) -> dict:
    url = _get_autorizacion_url(ambiente)
    headers = {"Content-Type": "text/xml; charset=utf-8"}
    body = f"""
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                          xmlns:aut="http://ec.gob.sri.ws.autorizacion">
           <soapenv:Header/>
           <soapenv:Body>
              <aut:autorizacionComprobante>
                 <claveAccesoComprobante>{clave_acceso}</claveAccesoComprobante>
              </aut:autorizacionComprobante>
           </soapenv:Body>
        </soapenv:Envelope>
    """

    try:
        response = requests.post(url, data=body.encode("utf-8"), headers=headers, timeout=30)
    except Exception as e:
        return {"estado": "ERROR", "mensajes": [f"Excepción HTTP: {e!r}"], "raw_xml": ""}

    if response.status_code != 200:
        return {"estado": "ERROR", "mensajes": [f"HTTP {response.status_code}"], "raw_xml": response.text}

    response_xml = response.text
    try:
        root = etree.fromstring(response_xml.encode("utf-8"))
        auto_nodes = root.xpath('//autorizacion')
        if not auto_nodes:
            if debug:
                _emit_debug("SRI Autorización SOAP envelope (no <autorizacion>)", response_xml)
            return {
                "estado": "ERROR",
                "mensajes": ["No se encontró <autorizacion> en la respuesta"],
                "raw_soap_envelope": response_xml,
                "raw_xml": response_xml,
            }

        auto_el = auto_nodes[0]
        estado = (auto_el.findtext("estado") or "")
        numero = auto_el.findtext("numeroAutorizacion")
        fecha_txt = auto_el.findtext("fechaAutorizacion")

        xml_autorizado_inner = auto_el.findtext("comprobante") or ""   # inner <factura> as text (likely CDATA)
        autorizacion_xml = etree.tostring(auto_el, encoding="utf-8", xml_declaration=True).decode("utf-8")

        mensajes = []
        for m in auto_el.findall("mensajes/mensaje"):
            mensajes.append({
                "identificador": m.findtext("identificador"),
                "mensaje": m.findtext("mensaje"),
                "informacionAdicional": m.findtext("informacionAdicional"),
                "tipo": m.findtext("tipo"),
            })

        if debug:
            _emit_debug("SRI Autorización SOAP envelope", response_xml)
            _emit_debug("SRI Autorización <autorizacion>", autorizacion_xml)
            if xml_autorizado_inner:
                _emit_debug("SRI Autorización <comprobante> (inner factura)", xml_autorizado_inner)

        return {
            "estado": estado,                        # AUTORIZADO | NO AUTORIZADO
            "numero": numero,
            "fecha_txt": fecha_txt,                  # keep raw; caller can parse if needed
            "xml_autorizado": xml_autorizado_inner,  # inner factura (string)
            "autorizacion_xml": autorizacion_xml,    # full <autorizacion> wrapper (string)  ⟵ save this for “header”
            "raw_soap_envelope": response_xml,       # whole SOAP for deep debug
            "raw_xml": autorizacion_xml,             # legacy-ish: points to wrapper, not SOAP
            "mensajes": mensajes,
        }

    except Exception as e:
        return {
            "estado": "ERROR",
            "mensajes": [f"Excepción parseando respuesta: {e!r}"],
            "raw_soap_envelope": response_xml,
            "raw_xml": response_xml,
        }