import re
import frappe

RE3 = re.compile(r"^\d{3}$")

def validate_warehouse_sri(doc, method):
    # 3.1 establishment code (one per warehouse)
    est = (doc.get("custom_establishment_code") or "").strip()
    if not est or not RE3.match(est):
        frappe.throw("Código de Establecimiento debe tener exactamente 3 dígitos (000–999).")

    # 3.2 puntos de emisión
    rows = getattr(doc, "custom_sri_puntos_emision", []) or []
    seen_points = set()

    for i, row in enumerate(rows, start=1):
        pe = (row.emission_point_code or "").strip()
        if not pe or not RE3.match(pe):
            frappe.throw(f"Fila {i}: Punto de Emisión debe tener exactamente 3 dígitos (000–999).")

        if pe in seen_points:
            frappe.throw(f"Fila {i}: Punto de Emisión duplicado ({pe}). Debe ser único por almacén.")
        seen_points.add(pe)

        # all sequences must be integers >= 0
        for field, label in [
            ("seq_factura_start", "Factura"),
            ("seq_nc_start", "Nota Crédito"),
            ("seq_nd_start", "Nota Débito"),
            ("seq_ret_start", "Comprobante Retención"),
            ("seq_liq_start", "Liquidación Compra"),
            ("seq_gr_start", "Guía de Remisión"),
        ]:
            val = getattr(row, field, None)
            if val is None or int(val) < 0:
                frappe.throw(f"Fila {i}: Secuencial inicial inválido para {label}. Debe ser ≥ 0.")

        # estado required
        if not row.estado:
            frappe.throw(f"Fila {i}: Estado es requerido (ACTIVO/INACTIVO).")
